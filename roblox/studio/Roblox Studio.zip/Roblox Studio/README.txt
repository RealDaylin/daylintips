Just open the RobloxStudioLauncherBeta.exe file, it will install Roblox Studio on your device.



NOTE: Roblox Studio can only be installed on Windows. Don't try to install it on your iOS or other devices.